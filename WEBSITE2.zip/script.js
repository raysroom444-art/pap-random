// PATH FOTO RELATIVE
const allImages = [
"images/IMG_20250908_231135_805.jpg", 
"images/IMG-20250909-WA0005.jpg", 
"images/IMG-20250909-WA0006.jpg", 
"images/IMG-20250909-WA0007.jpg", 
"images/IMG_20250729_125217_460.jpg", 
"images/IMG_20250906_064915_030.jpg", 
"images/IMG_20250906_215051_743.jpg", 
"images/IMG_20250906_223240_313.jpg", 
"images/IMG_20250729_180457_048.jpg", 
"images/IMG_20250729_125218_043.jpg", 
"images/IMG_20250612_004953_413.jpg", 
"images/IMG_20250612_004953_058.jpg ", 
  // Tambah semua foto kamu di sini
];

// DOM ELEMENTS
const photoGrid = document.getElementById("photoGrid");
const modal = document.getElementById("myModal");
const modalImg = document.getElementById("modalImg");
const modalTitle = document.getElementById("modalTitle");
const modalDesc = document.getElementById("modalDesc");
const closeModal = document.querySelector(".close");
const toggleDark = document.getElementById("toggleDark");
const searchInput = document.getElementById("searchInput");

// GENERATE DESKRIPSI OTOMATIS
const descriptions = allImages.map(path => {
  let name = path.split('/').pop().replace(/\.[^/.]+$/, "");
  return name.replace(/[_-]/g, " ");
});

// PAGINATION / INFINITE SCROLL
let loadedCount = 0;
const loadStep = 20; // jumlah foto per scroll
function loadMorePhotos() {
  const next = allImages.slice(loadedCount, loadedCount + loadStep);
  renderPhotos(next);
  loadedCount += next.length;
}

// RENDER PHOTO GRID
function renderPhotos(list) {
  list.forEach((src) => {
    const idx = allImages.indexOf(src);
    const card = document.createElement("div");
    card.className = "card";

    const img = document.createElement("img");
    img.src = src;
    img.alt = "Pinterest photo";

    const likeBtn = document.createElement("div");
    likeBtn.className = "like-btn";
    likeBtn.innerHTML = "♡ 0";

    let liked = false;
    likeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      liked = !liked;
      likeBtn.innerHTML = liked ? "❤️ 1" : "♡ 0";
      likeBtn.classList.toggle("liked", liked);
    });

    img.addEventListener("click", () => {
      modal.style.display = "flex";
      modalImg.src = src;
      modalTitle.textContent = `Foto ${idx + 1}`;
      modalDesc.textContent = descriptions[idx];

      const wrapper = document.querySelector(".modal-content-wrapper");
      wrapper.style.animation = "none";
      wrapper.offsetHeight;
      wrapper.style.animation = "modalZoomFade 0.3s ease forwards";
    });

    card.appendChild(img);
    card.appendChild(likeBtn);
    photoGrid.appendChild(card);
  });
}

// SEARCH FILTER
searchInput.addEventListener("input", () => {
  const value = searchInput.value.toLowerCase();
  photoGrid.innerHTML = "";
  loadedCount = 0;
  const filtered = allImages.filter(src => src.toLowerCase().includes(value));
  filtered.forEach((src, i) => {
    if (i < loadStep) renderPhotos([src]);
    loadedCount++;
  });
});

// CLOSE MODAL
closeModal.onclick = () => { modal.style.display = "none"; };
window.onclick = (event) => { if(event.target === modal) modal.style.display="none"; };

// DARK MODE
toggleDark.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  toggleDark.textContent = document.body.classList.contains("dark") ? "☀️" : "🌙";
});

// INFINITE SCROLL
window.addEventListener("scroll", () => {
  if(window.innerHeight + window.scrollY >= document.body.offsetHeight - 200) {
    if (loadedCount < allImages.length) loadMorePhotos();
  }
});

// INIT
loadMorePhotos();